﻿using KURSOVAYA.Model;
using KURSOVAYA.View.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KURSOVAYA.View.Pages
{
    /// <summary>
    /// Логика взаимодействия для CatalogPage.xaml
    /// </summary>
    public partial class CatalogPage : Page
    {
        private List<Show> show = App.context.Show.ToList();
        public CatalogPage()
        {
            InitializeComponent();

            ShowLv.ItemsSource = show;
        }

        private void MoreInformationBtn_Click(object sender, RoutedEventArgs e)
        {

            
                

            var button = sender as Button;
            if (button == null) return;

            var selectedShow = button.DataContext as Show; 
            if (selectedShow == null) return;
            NavigationService.Navigate(new View.Pages.InformationAboutShowPage(selectedShow));
        }


        

        private void MoreInformationBtn2_Click(object sender, RoutedEventArgs e)
        {

            //Show selectedShow = ShowLv.SelectedItem as Show;



            //InformationShowWindow informationShowWindow = new InformationShowWindow();
            //informationShowWindow.ShowDialog();

        }
    }
}

